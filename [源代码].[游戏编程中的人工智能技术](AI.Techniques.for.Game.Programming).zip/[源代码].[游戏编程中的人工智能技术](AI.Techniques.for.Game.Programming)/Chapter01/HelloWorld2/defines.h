#ifndef DEFINES_H
#define DEFINES_H

#define WINDOW_WIDTH  400
#define WINDOW_HEIGHT 400

#endif