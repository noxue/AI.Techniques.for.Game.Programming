//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define ID_SCALE_NORMAL                 40001
#define ID_SCALE_NONE                   40001
#define ID_SCALE_RANK                   40002
#define ID_SCALE_LINEAR                 40003
#define ID_MUTATE_EX                    40004
#define ID_MUTATE_EM                    40004
#define ID_MUTATE_SM                    40005
#define ID_MUTATE_IM                    40006
#define ID_MUTATION_DM                  40007
#define ID_MUTATE_DM                    40007
#define ID_SCALE_SIGMA                  40008
#define ID_SCALE_BOLTZMANN              40009
#define ID_SELECT_ROULETTE              40010
#define ID_SELECT_TOURNAMENT            40011
#define ID_SELECT_ALTTOURNAMENT         40012
#define ID_CROSSOVER_PMX                40014
#define ID_CROSSOVER_OBX                40015
#define ID_SELECT_SUS                   40016
#define ID_ELITISM_ON                   40017
#define ID_ELITISM_OFF                  40018
#define ID_CROSSOVER_PBX                40019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40020
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
