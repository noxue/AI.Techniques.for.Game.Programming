//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define IDD_DIALOG1                     102
#define IDD_DIALOG2                     103
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define ID_BALL_OPTIONS                 40001
#define ID_ABOUT                        40002
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
