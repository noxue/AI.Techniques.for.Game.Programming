#ifndef DEFINES_H
#define DEFINES_H

#define WINDOW_WIDTH  400
#define WINDOW_HEIGHT 400

#define NUM_VERTS     5

#endif